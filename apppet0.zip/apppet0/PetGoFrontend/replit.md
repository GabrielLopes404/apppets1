# PetGo - Pet Services Marketplace

## Overview

PetGo is a mobile-first marketplace application for pet services and products, built with React Native and Expo. The app connects pet owners with nearby pet stores, veterinary clinics, grooming services, and product retailers. Currently implemented as a frontend-only application with mock data, designed for seamless integration with a future backend.

The application provides a modern, premium user experience with smooth animations, intuitive navigation, and a clean design aesthetic inspired by leading marketplace apps like Uber, Rappi, and DoorDash.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Platform**
- React Native 0.81.5 with Expo ~54.0.23
- Cross-platform mobile application (iOS & Android)
- New Architecture enabled for improved performance
- React 19.1.0 for latest component patterns

**Navigation Structure**
- React Navigation v7 with nested navigation pattern
- Stack Navigator for screen transitions with slide/fade animations
- Bottom Tab Navigator for main app sections (Home, Cart, Profile)
- Deep linking support for individual stores and products

**State Management**
- React Context API for global state
- AuthContext: User authentication and session management
- CartContext: Shopping cart operations and persistence
- AsyncStorage for local data persistence

**UI/UX Design System**
- Custom theme system with centralized design tokens
- Color palette: Primary (#FF6B6B), Secondary (#4ECDC4), Accent (#FFD93D)
- Typography system with 9 size variants and weight presets
- Spacing system using 8px base unit (xs to 5xl)
- Border radius variants (sm to full/pill)
- Shadow system with 4 elevation levels
- Micro-animations using React Native Reanimated
- Skeleton loaders for loading states

**Component Architecture**
- Atomic design pattern: Common components (Button, Input, Card) + UI components (StoreCard, ProductCard)
- Reusable, composable components with consistent prop interfaces
- Safe area handling for notch/edge-to-edge displays
- Gesture handling via react-native-gesture-handler

**Screen Flow**
1. Onboarding (3 slides) → Authentication
2. Login/Register/Password Recovery
3. Location Permission (GPS or manual ZIP code)
4. Main Tabs: Home (store discovery) | Cart | Profile
5. Store Details with tabs (Products, Services, Reviews)
6. Product/Service booking and checkout
7. Payment (PIX QR code simulation)
8. Order tracking with status updates

### Data Layer

**Mock Data Strategy**
- Structured mock data in `src/data/mockData.js`
- Simulates backend responses with realistic delays
- Data models: Stores, Products, Services, Reviews, Orders, Pets, User
- Ready for API integration (RESTful or GraphQL)

**Data Models**
- Store: id, name, category, rating, distance, hours, contact
- Product: id, storeId, name, price, image, description, category
- Service: id, storeId, name, price, duration, description
- Cart: items with quantity tracking, total calculation
- Order: id, items, status, date, delivery type

### External Dependencies

**Core Libraries**
- `@react-navigation/*` - Navigation infrastructure (stack, tabs, native)
- `react-native-safe-area-context` - Safe area boundaries
- `react-native-screens` - Native screen optimization
- `react-native-gesture-handler` - Touch/gesture system
- `react-native-reanimated` - High-performance animations

**UI & Assets**
- `@expo/vector-icons` - Icon library (Ionicons)
- `expo-linear-gradient` - Gradient backgrounds
- `expo-image-picker` - Image selection (pet photos, profile)
- `expo-status-bar` - Status bar styling

**Storage**
- `@react-native-async-storage/async-storage` - Local data persistence for user sessions and preferences

**Platform Support**
- Expo SDK for unified iOS/Android/Web builds
- Edge-to-edge Android display support
- iOS tablet compatibility

### Future Backend Integration Points

**Authentication**
- Current: Mock login with AsyncStorage
- Future: JWT/OAuth integration, social login providers

**API Endpoints** (Expected)
- `/stores` - GET stores by location/category
- `/products` - GET products by store
- `/services` - GET services by store
- `/orders` - POST create order, GET order history
- `/bookings` - POST create service booking
- `/reviews` - GET/POST store reviews
- `/user/pets` - CRUD pet profiles

**Real-time Features** (Planned)
- WebSocket for order tracking updates
- Push notifications for order status changes
- Live location tracking for delivery

**Payment Integration** (Planned)
- PIX payment gateway integration
- Credit card processing
- Payment confirmation webhooks

**Database** (Future)
- Expected: PostgreSQL or similar relational database
- ORM: Potential Drizzle integration
- Schema: Users, Stores, Products, Services, Orders, Bookings, Reviews, Pets