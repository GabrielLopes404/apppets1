export const animationConfig = {
  timing: {
    fast: 150,
    normal: 250,
    slow: 350,
    verySlow: 500,
  },
  
  spring: {
    gentle: {
      damping: 20,
      stiffness: 90,
    },
    medium: {
      damping: 15,
      stiffness: 150,
    },
    bouncy: {
      damping: 10,
      stiffness: 200,
    },
    snappy: {
      damping: 25,
      stiffness: 300,
    },
  },
  
  gesture: {
    swipeVelocityThreshold: 500,
    swipeDistanceThreshold: 100,
    longPressDelay: 500,
  },
  
  haptic: {
    light: 'light',
    medium: 'medium',
    heavy: 'heavy',
    success: 'notificationSuccess',
    warning: 'notificationWarning',
    error: 'notificationError',
  },
};

export const animations = {
  fadeIn: {
    from: { opacity: 0 },
    to: { opacity: 1 },
  },
  
  fadeOut: {
    from: { opacity: 1 },
    to: { opacity: 0 },
  },
  
  slideInUp: {
    from: { translateY: 50, opacity: 0 },
    to: { translateY: 0, opacity: 1 },
  },
  
  slideInDown: {
    from: { translateY: -50, opacity: 0 },
    to: { translateY: 0, opacity: 1 },
  },
  
  slideInLeft: {
    from: { translateX: -50, opacity: 0 },
    to: { translateX: 0, opacity: 1 },
  },
  
  slideInRight: {
    from: { translateX: 50, opacity: 0 },
    to: { translateX: 0, opacity: 1 },
  },
  
  scaleIn: {
    from: { scale: 0.8, opacity: 0 },
    to: { scale: 1, opacity: 1 },
  },
  
  scaleOut: {
    from: { scale: 1, opacity: 1 },
    to: { scale: 0.8, opacity: 0 },
  },
  
  bounce: {
    keyframes: [
      { scale: 1 },
      { scale: 1.1 },
      { scale: 0.95 },
      { scale: 1 },
    ],
  },
  
  pulse: {
    keyframes: [
      { scale: 1, opacity: 1 },
      { scale: 1.05, opacity: 0.8 },
      { scale: 1, opacity: 1 },
    ],
  },
  
  shake: {
    keyframes: [
      { translateX: 0 },
      { translateX: -10 },
      { translateX: 10 },
      { translateX: -10 },
      { translateX: 10 },
      { translateX: 0 },
    ],
  },
};
