export const lightColors = {
  primary: '#FF6B6B',
  primaryDark: '#E85555',
  primaryLight: '#FF8787',
  
  secondary: '#4ECDC4',
  secondaryDark: '#3DB8AF',
  secondaryLight: '#6ED9D0',
  
  accent: '#FFD93D',
  accentDark: '#F5C72E',
  accentLight: '#FFE36B',
  
  success: '#51CF66',
  warning: '#FFB84D',
  error: '#FF6B6B',
  info: '#4ECDC4',
  
  background: '#FFFFFF',
  backgroundSecondary: '#F8F9FA',
  backgroundTertiary: '#E9ECEF',
  
  text: '#2D3436',
  textSecondary: '#636E72',
  textLight: '#B2BEC3',
  textInverse: '#FFFFFF',
  
  border: '#DFE6E9',
  borderLight: '#F0F3F4',
  
  card: '#FFFFFF',
  cardShadow: 'rgba(0, 0, 0, 0.08)',
  
  overlay: 'rgba(0, 0, 0, 0.5)',
  overlayLight: 'rgba(0, 0, 0, 0.3)',
  
  rating: '#FFC107',
  
  categories: {
    grooming: '#FF6B6B',
    veterinary: '#4ECDC4',
    products: '#FFD93D',
  },
};

export const darkColors = {
  primary: '#FF6B6B',
  primaryDark: '#FF8787',
  primaryLight: '#E85555',
  
  secondary: '#4ECDC4',
  secondaryDark: '#6ED9D0',
  secondaryLight: '#3DB8AF',
  
  accent: '#FFD93D',
  accentDark: '#FFE36B',
  accentLight: '#F5C72E',
  
  success: '#51CF66',
  warning: '#FFB84D',
  error: '#FF6B6B',
  info: '#4ECDC4',
  
  background: '#0D1117',
  backgroundSecondary: '#161B22',
  backgroundTertiary: '#1C2128',
  
  text: '#E6EDF3',
  textSecondary: '#7D8590',
  textLight: '#484F58',
  textInverse: '#0D1117',
  
  border: '#30363D',
  borderLight: '#21262D',
  
  card: '#161B22',
  cardShadow: 'rgba(0, 0, 0, 0.4)',
  
  overlay: 'rgba(0, 0, 0, 0.7)',
  overlayLight: 'rgba(0, 0, 0, 0.5)',
  
  rating: '#FFC107',
  
  categories: {
    grooming: '#FF6B6B',
    veterinary: '#4ECDC4',
    products: '#FFD93D',
  },
};

export const gradients = {
  primary: ['#FF6B6B', '#FF8787'],
  secondary: ['#4ECDC4', '#6ED9D0'],
  accent: ['#FFD93D', '#FFE36B'],
  
  sunset: ['#FF6B6B', '#FFD93D'],
  ocean: ['#4ECDC4', '#667EEA'],
  forest: ['#51CF66', '#4ECDC4'],
  
  pinkPurple: ['#FF6B9D', '#C44569'],
  blueGreen: ['#4ECDC4', '#44A08D'],
  orangeRed: ['#FF6B6B', '#FF8E53'],
  
  purpleBlue: ['#667EEA', '#764BA2'],
  warmFlame: ['#FF9A56', '#FF6A88'],
  
  glass: 'rgba(255, 255, 255, 0.1)',
  glassDark: 'rgba(0, 0, 0, 0.2)',
};

export const colors = lightColors;
