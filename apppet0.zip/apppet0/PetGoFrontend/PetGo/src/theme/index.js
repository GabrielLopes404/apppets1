import { lightColors, darkColors, gradients } from './colors';
import { typography } from './typography';
import { spacing, borderRadius, shadows, blur, glassmorphism } from './spacing';

export const theme = {
  colors: lightColors,
  darkColors,
  gradients,
  typography,
  spacing,
  borderRadius,
  shadows,
  blur,
  glassmorphism,
};

export { lightColors, darkColors, gradients, typography, spacing, borderRadius, shadows, blur, glassmorphism };

export const colors = lightColors;
