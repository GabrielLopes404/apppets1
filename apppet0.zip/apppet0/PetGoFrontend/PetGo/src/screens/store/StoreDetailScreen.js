import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { ProductCard } from '../../components/ui/ProductCard';
import { Button } from '../../components/common';
import { mockProducts, mockServices, mockReviews } from '../../data/mockData';
import { colors, typography, spacing, borderRadius } from '../../theme';

export const StoreDetailScreen = ({ route, navigation }) => {
  const { store } = route.params;
  const [activeTab, setActiveTab] = useState('Produtos');

  const tabs = ['Produtos', 'Serviços', 'Avaliações'];

  const storeProducts = mockProducts.filter(product => product.storeId === store.id);
  const storeServices = mockServices.filter(service => service.storeId === store.id);
  const storeReviews = mockReviews.filter(review => review.storeId === store.id);

  const renderTabContent = () => {
    if (activeTab === 'Produtos') {
      return (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.productsContainer}>
          {storeProducts.length > 0 ? (
            storeProducts.map(product => (
              <ProductCard
                key={product.id}
                product={product}
                onPress={() => navigation.navigate('Product', { product, store })}
              />
            ))
          ) : (
            <Text style={styles.emptyText}>Nenhum produto disponível</Text>
          )}
        </ScrollView>
      );
    }

    if (activeTab === 'Serviços') {
      return (
        <View style={styles.servicesContainer}>
          {storeServices.length > 0 ? (
            storeServices.map(service => (
              <TouchableOpacity
                key={service.id}
                style={styles.serviceCard}
                onPress={() => navigation.navigate('Booking', { service, store })}
              >
                <View style={styles.serviceInfo}>
                  <Text style={styles.serviceName}>{service.name}</Text>
                  <Text style={styles.serviceDescription}>{service.description}</Text>
                  <Text style={styles.serviceDuration}>Duração: {service.duration}</Text>
                </View>
                <View style={styles.servicePrice}>
                  <Text style={styles.servicePriceText}>R$ {service.price.toFixed(2)}</Text>
                  <Ionicons name="chevron-forward" size={20} color={colors.textSecondary} />
                </View>
              </TouchableOpacity>
            ))
          ) : (
            <Text style={styles.emptyText}>Nenhum serviço disponível</Text>
          )}
        </View>
      );
    }

    return (
      <View style={styles.reviewsContainer}>
        {storeReviews.length > 0 ? (
          storeReviews.map(review => (
            <View key={review.id} style={styles.reviewCard}>
              <View style={styles.reviewHeader}>
                <Text style={styles.reviewUserName}>{review.userName}</Text>
                <View style={styles.reviewRating}>
                  <Ionicons name="star" size={14} color={colors.rating} />
                  <Text style={styles.reviewRatingText}>{review.rating.toFixed(1)}</Text>
                </View>
              </View>
              <Text style={styles.reviewComment}>{review.comment}</Text>
              <Text style={styles.reviewDate}>{new Date(review.date).toLocaleDateString('pt-BR')}</Text>
            </View>
          ))
        ) : (
          <Text style={styles.emptyText}>Nenhuma avaliação disponível</Text>
        )}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <Image source={{ uri: store.image }} style={styles.coverImage} resizeMode="cover" />
        
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color={colors.textInverse} />
        </TouchableOpacity>

        <View style={styles.content}>
          <Text style={styles.storeName}>{store.name}</Text>
          <Text style={styles.storeCategory}>{store.category}</Text>

          <View style={styles.storeMetrics}>
            <View style={styles.metric}>
              <Ionicons name="star" size={16} color={colors.rating} />
              <Text style={styles.metricText}>{store.rating.toFixed(1)} ({store.reviewCount})</Text>
            </View>
            <View style={styles.metric}>
              <Ionicons name="location" size={16} color={colors.textSecondary} />
              <Text style={styles.metricText}>{store.distance}</Text>
            </View>
            <View style={styles.metric}>
              <Ionicons name="time" size={16} color={colors.textSecondary} />
              <Text style={styles.metricText}>{store.hours}</Text>
            </View>
          </View>

          <Text style={styles.description}>{store.description}</Text>

          <View style={styles.tabsContainer}>
            {tabs.map(tab => (
              <TouchableOpacity
                key={tab}
                style={[styles.tab, activeTab === tab && styles.tabActive]}
                onPress={() => setActiveTab(tab)}
              >
                <Text style={[styles.tabText, activeTab === tab && styles.tabTextActive]}>
                  {tab}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {renderTabContent()}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  coverImage: {
    width: '100%',
    height: 250,
  },
  backButton: {
    position: 'absolute',
    top: 50,
    left: spacing.base,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    padding: spacing.xl,
  },
  storeName: {
    fontSize: typography.fontSize['3xl'],
    fontWeight: typography.fontWeight.bold,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  storeCategory: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
    marginBottom: spacing.base,
  },
  storeMetrics: {
    flexDirection: 'row',
    marginBottom: spacing.base,
  },
  metric: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: spacing.lg,
  },
  metricText: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    marginLeft: spacing.xs,
  },
  description: {
    fontSize: typography.fontSize.base,
    color: colors.text,
    lineHeight: typography.fontSize.base * typography.lineHeight.relaxed,
    marginBottom: spacing.xl,
  },
  tabsContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    marginBottom: spacing.base,
  },
  tab: {
    flex: 1,
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  tabActive: {
    borderBottomWidth: 2,
    borderBottomColor: colors.primary,
  },
  tabText: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
  },
  tabTextActive: {
    color: colors.primary,
    fontWeight: typography.fontWeight.semibold,
  },
  productsContainer: {
    marginTop: spacing.base,
  },
  servicesContainer: {
    marginTop: spacing.base,
  },
  serviceCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.base,
    backgroundColor: colors.card,
    borderRadius: borderRadius.md,
    marginBottom: spacing.md,
  },
  serviceInfo: {
    flex: 1,
  },
  serviceName: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  serviceDescription: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  serviceDuration: {
    fontSize: typography.fontSize.xs,
    color: colors.textLight,
  },
  servicePrice: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  servicePriceText: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.bold,
    color: colors.primary,
    marginRight: spacing.xs,
  },
  reviewsContainer: {
    marginTop: spacing.base,
  },
  reviewCard: {
    padding: spacing.base,
    backgroundColor: colors.card,
    borderRadius: borderRadius.md,
    marginBottom: spacing.md,
  },
  reviewHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: spacing.sm,
  },
  reviewUserName: {
    fontSize: typography.fontSize.base,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text,
  },
  reviewRating: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  reviewRatingText: {
    fontSize: typography.fontSize.sm,
    color: colors.text,
    marginLeft: spacing.xs,
  },
  reviewComment: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    lineHeight: typography.fontSize.sm * typography.lineHeight.relaxed,
    marginBottom: spacing.xs,
  },
  reviewDate: {
    fontSize: typography.fontSize.xs,
    color: colors.textLight,
  },
  emptyText: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
    textAlign: 'center',
    padding: spacing.xl,
  },
});
