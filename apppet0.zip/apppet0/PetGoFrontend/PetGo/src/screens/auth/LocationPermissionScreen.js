import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Button, Input } from '../../components/common';
import { colors, typography, spacing } from '../../theme';

export const LocationPermissionScreen = ({ navigation }) => {
  const [zipCode, setZipCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleUseLocation = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      navigation.replace('MainTabs');
    }, 1000);
  };

  const handleManualZipCode = () => {
    if (zipCode.length >= 8) {
      navigation.replace('MainTabs');
    } else {
      alert('Digite um CEP válido');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.header}>
          <Ionicons name="location" size={100} color={colors.primary} />
          <Text style={styles.title}>Onde você está?</Text>
          <Text style={styles.subtitle}>
            Precisamos da sua localização para encontrar os melhores serviços perto de você
          </Text>
        </View>

        <View style={styles.buttonContainer}>
          <Button
            title="Usar Minha Localização"
            onPress={handleUseLocation}
            loading={isLoading}
            icon={<Ionicons name="navigate" size={20} color={colors.textInverse} style={{ marginRight: 8 }} />}
          />

          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>OU</Text>
            <View style={styles.dividerLine} />
          </View>

          <Input
            placeholder="Digite seu CEP"
            value={zipCode}
            onChangeText={setZipCode}
            keyboardType="number-pad"
            maxLength={8}
            leftIcon={<Ionicons name="search-outline" size={20} color={colors.textSecondary} />}
          />

          <Button
            title="Continuar com CEP"
            onPress={handleManualZipCode}
            variant="outline"
          />
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flex: 1,
    paddingHorizontal: spacing.xl,
    justifyContent: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: spacing['4xl'],
  },
  title: {
    fontSize: typography.fontSize['3xl'],
    fontWeight: typography.fontWeight.bold,
    color: colors.text,
    marginTop: spacing.xl,
    marginBottom: spacing.md,
  },
  subtitle: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: typography.fontSize.base * typography.lineHeight.relaxed,
    paddingHorizontal: spacing.base,
  },
  buttonContainer: {
    width: '100%',
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: spacing.xl,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: colors.border,
  },
  dividerText: {
    marginHorizontal: spacing.base,
    color: colors.textSecondary,
    fontSize: typography.fontSize.sm,
  },
});
