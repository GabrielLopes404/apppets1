import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, Modal, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Button, Card } from '../../components/common';
import { mockPets } from '../../data/mockData';
import { colors, typography, spacing, borderRadius } from '../../theme';

export const MyPetsScreen = ({ navigation }) => {
  const [pets, setPets] = useState(mockPets);
  const [showModal, setShowModal] = useState(false);
  const [newPet, setNewPet] = useState({ name: '', type: '', breed: '', age: '' });

  const handleAddPet = () => {
    if (newPet.name && newPet.type && newPet.breed && newPet.age) {
      setPets([...pets, { 
        id: String(pets.length + 1), 
        ...newPet,
        image: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=400'
      }]);
      setNewPet({ name: '', type: '', breed: '', age: '' });
      setShowModal(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Meus Pets</Text>
        <TouchableOpacity onPress={() => setShowModal(true)}>
          <Ionicons name="add-circle-outline" size={24} color={colors.primary} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {pets.map(pet => (
          <Card key={pet.id} style={styles.petCard}>
            <Image source={{ uri: pet.image }} style={styles.petImage} resizeMode="cover" />
            <View style={styles.petInfo}>
              <Text style={styles.petName}>{pet.name}</Text>
              <Text style={styles.petDetails}>{pet.type} • {pet.breed}</Text>
              <Text style={styles.petAge}>{pet.age}</Text>
            </View>
            <TouchableOpacity style={styles.editButton}>
              <Ionicons name="create-outline" size={20} color={colors.textSecondary} />
            </TouchableOpacity>
          </Card>
        ))}

        {pets.length === 0 && (
          <View style={styles.emptyState}>
            <Ionicons name="paw-outline" size={80} color={colors.textLight} />
            <Text style={styles.emptyTitle}>Nenhum pet cadastrado</Text>
            <Text style={styles.emptySubtitle}>Adicione seus pets para facilitar os agendamentos</Text>
          </View>
        )}
      </ScrollView>

      <Modal
        visible={showModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Adicionar Pet</Text>
              <TouchableOpacity onPress={() => setShowModal(false)}>
                <Ionicons name="close" size={24} color={colors.text} />
              </TouchableOpacity>
            </View>

            <TextInput
              style={styles.input}
              placeholder="Nome do pet"
              placeholderTextColor={colors.textLight}
              value={newPet.name}
              onChangeText={(text) => setNewPet({ ...newPet, name: text })}
            />

            <TextInput
              style={styles.input}
              placeholder="Tipo (Cachorro, Gato, etc)"
              placeholderTextColor={colors.textLight}
              value={newPet.type}
              onChangeText={(text) => setNewPet({ ...newPet, type: text })}
            />

            <TextInput
              style={styles.input}
              placeholder="Raça"
              placeholderTextColor={colors.textLight}
              value={newPet.breed}
              onChangeText={(text) => setNewPet({ ...newPet, breed: text })}
            />

            <TextInput
              style={styles.input}
              placeholder="Idade (ex: 3 anos)"
              placeholderTextColor={colors.textLight}
              value={newPet.age}
              onChangeText={(text) => setNewPet({ ...newPet, age: text })}
            />

            <Button title="Adicionar" onPress={handleAddPet} style={styles.addButton} />
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.base,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: {
    fontSize: typography.fontSize.xl,
    fontWeight: typography.fontWeight.bold,
    color: colors.text,
  },
  content: {
    flex: 1,
    paddingHorizontal: spacing.xl,
    paddingTop: spacing.base,
  },
  petCard: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  petImage: {
    width: 70,
    height: 70,
    borderRadius: 35,
  },
  petInfo: {
    flex: 1,
    marginLeft: spacing.base,
  },
  petName: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  petDetails: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    marginBottom: 2,
  },
  petAge: {
    fontSize: typography.fontSize.xs,
    color: colors.textLight,
  },
  editButton: {
    padding: spacing.sm,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: spacing['5xl'],
  },
  emptyTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text,
    marginTop: spacing.xl,
    marginBottom: spacing.xs,
  },
  emptySubtitle: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.background,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: spacing.xl,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  modalTitle: {
    fontSize: typography.fontSize.xl,
    fontWeight: typography.fontWeight.bold,
    color: colors.text,
  },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    fontSize: typography.fontSize.base,
    color: colors.text,
    marginBottom: spacing.md,
  },
  addButton: {
    marginTop: spacing.base,
  },
});
