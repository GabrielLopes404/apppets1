import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Button, Card } from '../../components/common';
import { useCart } from '../../contexts/CartContext';
import { colors, typography, spacing } from '../../theme';

export const CartScreen = ({ navigation }) => {
  const { cartItems, updateQuantity, getTotal } = useCart();
  const [deliveryType, setDeliveryType] = useState('delivery');

  const handleCheckout = () => {
    navigation.navigate('Payment', { total: getTotal(), deliveryType });
  };

  if (cartItems.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Carrinho</Text>
        </View>
        <View style={styles.emptyContainer}>
          <Ionicons name="cart-outline" size={100} color={colors.textLight} />
          <Text style={styles.emptyTitle}>Seu carrinho está vazio</Text>
          <Text style={styles.emptySubtitle}>Adicione produtos para começar</Text>
          <Button
            title="Explorar Lojas"
            onPress={() => navigation.navigate('Home')}
            style={styles.exploreButton}
          />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Carrinho ({cartItems.length})</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {cartItems.map(item => (
          <Card key={item.id} style={styles.cartItem}>
            <Image source={{ uri: item.image }} style={styles.itemImage} resizeMode="cover" />
            <View style={styles.itemInfo}>
              <Text style={styles.itemName} numberOfLines={2}>{item.name}</Text>
              <Text style={styles.itemPrice}>R$ {item.price.toFixed(2)}</Text>
              <View style={styles.quantityContainer}>
                <TouchableOpacity
                  style={styles.quantityButton}
                  onPress={() => updateQuantity(item.id, item.quantity - 1)}
                >
                  <Ionicons name="remove" size={16} color={colors.text} />
                </TouchableOpacity>
                <Text style={styles.quantityText}>{item.quantity}</Text>
                <TouchableOpacity
                  style={styles.quantityButton}
                  onPress={() => updateQuantity(item.id, item.quantity + 1)}
                >
                  <Ionicons name="add" size={16} color={colors.text} />
                </TouchableOpacity>
              </View>
            </View>
            <TouchableOpacity
              style={styles.removeButton}
              onPress={() => updateQuantity(item.id, 0)}
            >
              <Ionicons name="trash-outline" size={20} color={colors.error} />
            </TouchableOpacity>
          </Card>
        ))}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Tipo de Entrega</Text>
          <TouchableOpacity
            style={[
              styles.deliveryOption,
              deliveryType === 'delivery' && styles.deliveryOptionActive,
            ]}
            onPress={() => setDeliveryType('delivery')}
          >
            <Ionicons
              name="bicycle"
              size={24}
              color={deliveryType === 'delivery' ? colors.primary : colors.textSecondary}
            />
            <View style={styles.deliveryInfo}>
              <Text style={[
                styles.deliveryTitle,
                deliveryType === 'delivery' && styles.deliveryTitleActive,
              ]}>
                Delivery
              </Text>
              <Text style={styles.deliverySubtitle}>Receba em casa em 30-45 min</Text>
            </View>
            <Ionicons
              name={deliveryType === 'delivery' ? 'checkmark-circle' : 'ellipse-outline'}
              size={24}
              color={deliveryType === 'delivery' ? colors.primary : colors.border}
            />
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.deliveryOption,
              deliveryType === 'pickup' && styles.deliveryOptionActive,
            ]}
            onPress={() => setDeliveryType('pickup')}
          >
            <Ionicons
              name="bag-handle"
              size={24}
              color={deliveryType === 'pickup' ? colors.primary : colors.textSecondary}
            />
            <View style={styles.deliveryInfo}>
              <Text style={[
                styles.deliveryTitle,
                deliveryType === 'pickup' && styles.deliveryTitleActive,
              ]}>
                Retirar na Loja
              </Text>
              <Text style={styles.deliverySubtitle}>Sem taxa de entrega</Text>
            </View>
            <Ionicons
              name={deliveryType === 'pickup' ? 'checkmark-circle' : 'ellipse-outline'}
              size={24}
              color={deliveryType === 'pickup' ? colors.primary : colors.border}
            />
          </TouchableOpacity>
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Subtotal</Text>
          <Text style={styles.summaryValue}>R$ {getTotal().toFixed(2)}</Text>
        </View>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Taxa de Entrega</Text>
          <Text style={styles.summaryValue}>
            {deliveryType === 'delivery' ? 'R$ 8.00' : 'Grátis'}
          </Text>
        </View>
        <View style={styles.divider} />
        <View style={styles.summaryRow}>
          <Text style={styles.totalLabel}>Total</Text>
          <Text style={styles.totalValue}>
            R$ {(getTotal() + (deliveryType === 'delivery' ? 8 : 0)).toFixed(2)}
          </Text>
        </View>
        <Button title="Finalizar Pedido" onPress={handleCheckout} style={styles.checkoutButton} />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.base,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: {
    fontSize: typography.fontSize.xl,
    fontWeight: typography.fontWeight.bold,
    color: colors.text,
  },
  content: {
    flex: 1,
    paddingHorizontal: spacing.xl,
    paddingTop: spacing.base,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: spacing['3xl'],
  },
  emptyTitle: {
    fontSize: typography.fontSize.xl,
    fontWeight: typography.fontWeight.bold,
    color: colors.text,
    marginTop: spacing.xl,
    marginBottom: spacing.xs,
  },
  emptySubtitle: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
    marginBottom: spacing.xl,
  },
  exploreButton: {
    minWidth: 200,
  },
  cartItem: {
    flexDirection: 'row',
    marginBottom: spacing.md,
  },
  itemImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
  },
  itemInfo: {
    flex: 1,
    marginLeft: spacing.md,
  },
  itemName: {
    fontSize: typography.fontSize.base,
    fontWeight: typography.fontWeight.medium,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  itemPrice: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.bold,
    color: colors.primary,
    marginBottom: spacing.sm,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  quantityButton: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.backgroundSecondary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  quantityText: {
    fontSize: typography.fontSize.base,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text,
    marginHorizontal: spacing.md,
    minWidth: 24,
    textAlign: 'center',
  },
  removeButton: {
    padding: spacing.xs,
  },
  section: {
    marginTop: spacing.base,
    marginBottom: spacing.xl,
  },
  sectionTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text,
    marginBottom: spacing.md,
  },
  deliveryOption: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.base,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 12,
    marginBottom: spacing.md,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  deliveryOptionActive: {
    borderColor: colors.primary,
    backgroundColor: colors.background,
  },
  deliveryInfo: {
    flex: 1,
    marginLeft: spacing.md,
  },
  deliveryTitle: {
    fontSize: typography.fontSize.base,
    fontWeight: typography.fontWeight.medium,
    color: colors.textSecondary,
  },
  deliveryTitleActive: {
    color: colors.text,
    fontWeight: typography.fontWeight.semibold,
  },
  deliverySubtitle: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    marginTop: 2,
  },
  footer: {
    padding: spacing.xl,
    backgroundColor: colors.background,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: spacing.sm,
  },
  summaryLabel: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
  },
  summaryValue: {
    fontSize: typography.fontSize.base,
    color: colors.text,
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: spacing.md,
  },
  totalLabel: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text,
  },
  totalValue: {
    fontSize: typography.fontSize.xl,
    fontWeight: typography.fontWeight.bold,
    color: colors.primary,
  },
  checkoutButton: {
    marginTop: spacing.base,
  },
});
