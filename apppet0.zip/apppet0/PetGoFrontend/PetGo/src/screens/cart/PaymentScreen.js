import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Button } from '../../components/common';
import { useCart } from '../../contexts/CartContext';
import { colors, typography, spacing } from '../../theme';

export const PaymentScreen = ({ route, navigation }) => {
  const { total, deliveryType } = route.params;
  const [paymentStatus, setPaymentStatus] = useState('waiting');
  const { clearCart } = useCart();

  useEffect(() => {
    const timer = setTimeout(() => {
      setPaymentStatus('confirmed');
      clearCart();
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  const handleContinue = () => {
    navigation.navigate('OrderTracking', {
      type: 'order',
      orderId: Math.random().toString(36).substr(2, 9),
      total,
      deliveryType,
    });
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        {paymentStatus === 'waiting' ? (
          <>
            <Ionicons name="qr-code-outline" size={120} color={colors.text} />
            <Text style={styles.title}>Escaneie o QR Code</Text>
            <Text style={styles.subtitle}>Use o app do seu banco para pagar via PIX</Text>
            
            <View style={styles.qrContainer}>
              <View style={styles.qrPlaceholder}>
                <Ionicons name="qr-code" size={200} color={colors.textLight} />
              </View>
            </View>

            <View style={styles.infoContainer}>
              <Text style={styles.infoLabel}>Valor a pagar</Text>
              <Text style={styles.infoValue}>R$ {total.toFixed(2)}</Text>
            </View>

            <View style={styles.loadingContainer}>
              <View style={styles.spinner} />
              <Text style={styles.waitingText}>Aguardando pagamento...</Text>
            </View>
          </>
        ) : (
          <>
            <View style={styles.successIcon}>
              <Ionicons name="checkmark-circle" size={100} color={colors.success} />
            </View>
            <Text style={styles.successTitle}>Pagamento Confirmado!</Text>
            <Text style={styles.successSubtitle}>
              Seu pedido foi confirmado e está sendo preparado
            </Text>

            <View style={styles.detailsContainer}>
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Valor pago</Text>
                <Text style={styles.detailValue}>R$ {total.toFixed(2)}</Text>
              </View>
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Método</Text>
                <Text style={styles.detailValue}>PIX</Text>
              </View>
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Entrega</Text>
                <Text style={styles.detailValue}>
                  {deliveryType === 'delivery' ? 'Delivery' : 'Retirar na loja'}
                </Text>
              </View>
            </View>

            <Button
              title="Acompanhar Pedido"
              onPress={handleContinue}
              style={styles.continueButton}
            />
          </>
        )}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl,
  },
  title: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: typography.fontWeight.bold,
    color: colors.text,
    marginTop: spacing.xl,
    marginBottom: spacing.xs,
  },
  subtitle: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: spacing.xl,
  },
  qrContainer: {
    marginVertical: spacing.xl,
  },
  qrPlaceholder: {
    width: 250,
    height: 250,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoContainer: {
    width: '100%',
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 12,
    padding: spacing.base,
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  infoLabel: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  infoValue: {
    fontSize: typography.fontSize['3xl'],
    fontWeight: typography.fontWeight.bold,
    color: colors.primary,
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  spinner: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: colors.primary,
    borderTopColor: 'transparent',
    marginRight: spacing.sm,
  },
  waitingText: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
  },
  successIcon: {
    marginBottom: spacing.xl,
  },
  successTitle: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: typography.fontWeight.bold,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  successSubtitle: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: spacing['3xl'],
  },
  detailsContainer: {
    width: '100%',
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 12,
    padding: spacing.base,
    marginBottom: spacing.xl,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: spacing.sm,
  },
  detailLabel: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
  },
  detailValue: {
    fontSize: typography.fontSize.base,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text,
  },
  continueButton: {
    width: '100%',
  },
});
