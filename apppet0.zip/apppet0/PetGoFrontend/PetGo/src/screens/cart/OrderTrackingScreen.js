import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Button } from '../../components/common';
import { colors, typography, spacing } from '../../theme';

const STATUSES = ['Aguardando', 'Em andamento', 'Finalizado'];

export const OrderTrackingScreen = ({ route, navigation }) => {
  const { type, orderId } = route.params;
  const [currentStatus, setCurrentStatus] = useState(0);

  useEffect(() => {
    const timer1 = setTimeout(() => setCurrentStatus(1), 2000);
    const timer2 = setTimeout(() => setCurrentStatus(2), 5000);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, []);

  const getStatusIcon = (index) => {
    if (index < currentStatus) return 'checkmark-circle';
    if (index === currentStatus) return 'ellipse';
    return 'ellipse-outline';
  };

  const getStatusColor = (index) => {
    if (index <= currentStatus) return colors.primary;
    return colors.border;
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.header}>
          <Ionicons
            name={currentStatus === 2 ? 'checkmark-circle' : 'time-outline'}
            size={80}
            color={currentStatus === 2 ? colors.success : colors.primary}
          />
          <Text style={styles.title}>
            {currentStatus === 2 ? 'Pedido Finalizado!' : 'Acompanhe seu Pedido'}
          </Text>
          <Text style={styles.orderId}>#{orderId || 'ABC123XYZ'}</Text>
        </View>

        <View style={styles.statusContainer}>
          {STATUSES.map((status, index) => (
            <View key={status} style={styles.statusItem}>
              <View style={styles.statusIconContainer}>
                <Ionicons
                  name={getStatusIcon(index)}
                  size={32}
                  color={getStatusColor(index)}
                />
                {index < STATUSES.length - 1 && (
                  <View
                    style={[
                      styles.statusLine,
                      { backgroundColor: index < currentStatus ? colors.primary : colors.border },
                    ]}
                  />
                )}
              </View>
              <View style={styles.statusTextContainer}>
                <Text
                  style={[
                    styles.statusText,
                    index <= currentStatus && styles.statusTextActive,
                  ]}
                >
                  {status}
                </Text>
                {index === currentStatus && currentStatus !== 2 && (
                  <Text style={styles.statusSubtext}>Em progresso...</Text>
                )}
                {index < currentStatus && (
                  <Text style={styles.statusSubtext}>Concluído</Text>
                )}
              </View>
            </View>
          ))}
        </View>

        {currentStatus === 2 && (
          <View style={styles.completedContainer}>
            <Text style={styles.completedText}>
              {type === 'service'
                ? 'Seu serviço foi concluído com sucesso!'
                : 'Seu pedido foi entregue com sucesso!'}
            </Text>
          </View>
        )}
      </View>

      <View style={styles.footer}>
        {currentStatus === 2 ? (
          <Button
            title="Voltar para Home"
            onPress={() => navigation.navigate('Home')}
          />
        ) : (
          <Button
            title="Voltar"
            variant="outline"
            onPress={() => navigation.navigate('Home')}
          />
        )}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flex: 1,
    paddingHorizontal: spacing.xl,
    paddingTop: spacing['3xl'],
  },
  header: {
    alignItems: 'center',
    marginBottom: spacing['4xl'],
  },
  title: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: typography.fontWeight.bold,
    color: colors.text,
    marginTop: spacing.xl,
    marginBottom: spacing.xs,
  },
  orderId: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
  },
  statusContainer: {
    paddingHorizontal: spacing.base,
  },
  statusItem: {
    flexDirection: 'row',
    marginBottom: spacing['2xl'],
  },
  statusIconContainer: {
    alignItems: 'center',
    marginRight: spacing.base,
  },
  statusLine: {
    width: 2,
    flex: 1,
    marginTop: spacing.xs,
  },
  statusTextContainer: {
    flex: 1,
    paddingTop: spacing.xs,
  },
  statusText: {
    fontSize: typography.fontSize.lg,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  statusTextActive: {
    color: colors.text,
    fontWeight: typography.fontWeight.semibold,
  },
  statusSubtext: {
    fontSize: typography.fontSize.sm,
    color: colors.textLight,
  },
  completedContainer: {
    backgroundColor: colors.backgroundSecondary,
    padding: spacing.base,
    borderRadius: 12,
    marginTop: spacing.xl,
  },
  completedText: {
    fontSize: typography.fontSize.base,
    color: colors.text,
    textAlign: 'center',
  },
  footer: {
    padding: spacing.xl,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
});
