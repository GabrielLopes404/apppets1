import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Button, Card } from '../../components/common';
import { mockPets } from '../../data/mockData';
import { colors, typography, spacing, borderRadius } from '../../theme';

export const BookingScreen = ({ route, navigation }) => {
  const { service, store } = route.params;
  const [step, setStep] = useState(1);
  const [selectedPet, setSelectedPet] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);

  const dates = ['10/11', '11/11', '12/11', '13/11', '14/11'];
  const times = ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'];

  const handleConfirm = () => {
    navigation.navigate('OrderTracking', {
      type: 'service',
      service,
      store,
      pet: selectedPet,
      date: selectedDate,
      time: selectedTime,
    });
  };

  const renderStepContent = () => {
    if (step === 1) {
      return (
        <View>
          <Text style={styles.stepTitle}>Selecione o Pet</Text>
          {mockPets.map(pet => (
            <Card
              key={pet.id}
              style={[
                styles.petCard,
                selectedPet?.id === pet.id && styles.selectedCard,
              ]}
              onPress={() => {
                setSelectedPet(pet);
                setStep(2);
              }}
            >
              <View style={styles.petInfo}>
                <Text style={styles.petName}>{pet.name}</Text>
                <Text style={styles.petDetails}>{pet.breed} • {pet.age}</Text>
              </View>
              <Ionicons
                name={selectedPet?.id === pet.id ? 'checkmark-circle' : 'chevron-forward'}
                size={24}
                color={selectedPet?.id === pet.id ? colors.primary : colors.textSecondary}
              />
            </Card>
          ))}
        </View>
      );
    }

    if (step === 2) {
      return (
        <View>
          <Text style={styles.stepTitle}>Selecione a Data</Text>
          <View style={styles.dateGrid}>
            {dates.map(date => (
              <TouchableOpacity
                key={date}
                style={[
                  styles.dateChip,
                  selectedDate === date && styles.selectedChip,
                ]}
                onPress={() => {
                  setSelectedDate(date);
                  setStep(3);
                }}
              >
                <Text
                  style={[
                    styles.dateChipText,
                    selectedDate === date && styles.selectedChipText,
                  ]}
                >
                  {date}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      );
    }

    return (
      <View>
        <Text style={styles.stepTitle}>Selecione o Horário</Text>
        <View style={styles.timeGrid}>
          {times.map(time => (
            <TouchableOpacity
              key={time}
              style={[
                styles.timeChip,
                selectedTime === time && styles.selectedChip,
              ]}
              onPress={() => setSelectedTime(time)}
            >
              <Text
                style={[
                  styles.timeChipText,
                  selectedTime === time && styles.selectedChipText,
                ]}
              >
                {time}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => step > 1 ? setStep(step - 1) : navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Agendar Serviço</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.progressBar}>
        {[1, 2, 3].map(i => (
          <View
            key={i}
            style={[
              styles.progressStep,
              i <= step && styles.progressStepActive,
            ]}
          />
        ))}
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <Card style={styles.serviceCard}>
          <Text style={styles.serviceName}>{service.name}</Text>
          <Text style={styles.servicePrice}>R$ {service.price.toFixed(2)}</Text>
        </Card>

        {renderStepContent()}

        {step === 3 && selectedTime && (
          <View style={styles.summaryCard}>
            <Text style={styles.summaryTitle}>Resumo do Agendamento</Text>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Pet:</Text>
              <Text style={styles.summaryValue}>{selectedPet?.name}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Data:</Text>
              <Text style={styles.summaryValue}>{selectedDate}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Horário:</Text>
              <Text style={styles.summaryValue}>{selectedTime}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Valor:</Text>
              <Text style={styles.summaryValue}>R$ {service.price.toFixed(2)}</Text>
            </View>
          </View>
        )}
      </ScrollView>

      {step === 3 && selectedTime && (
        <View style={styles.footer}>
          <Button title="Confirmar Agendamento" onPress={handleConfirm} />
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.base,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text,
  },
  progressBar: {
    flexDirection: 'row',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.base,
  },
  progressStep: {
    flex: 1,
    height: 4,
    backgroundColor: colors.border,
    marginHorizontal: 2,
    borderRadius: 2,
  },
  progressStepActive: {
    backgroundColor: colors.primary,
  },
  content: {
    flex: 1,
    paddingHorizontal: spacing.xl,
    paddingTop: spacing.base,
  },
  serviceCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  serviceName: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text,
  },
  servicePrice: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.bold,
    color: colors.primary,
  },
  stepTitle: {
    fontSize: typography.fontSize.xl,
    fontWeight: typography.fontWeight.bold,
    color: colors.text,
    marginBottom: spacing.base,
  },
  petCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  selectedCard: {
    borderWidth: 2,
    borderColor: colors.primary,
  },
  petInfo: {
    flex: 1,
  },
  petName: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text,
  },
  petDetails: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  dateGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: spacing.base,
  },
  dateChip: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.md,
    backgroundColor: colors.backgroundSecondary,
    marginRight: spacing.md,
    marginBottom: spacing.md,
    minWidth: 80,
    alignItems: 'center',
  },
  selectedChip: {
    backgroundColor: colors.primary,
  },
  dateChipText: {
    fontSize: typography.fontSize.base,
    color: colors.text,
  },
  selectedChipText: {
    color: colors.textInverse,
    fontWeight: typography.fontWeight.semibold,
  },
  timeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: spacing.base,
  },
  timeChip: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.md,
    backgroundColor: colors.backgroundSecondary,
    marginRight: spacing.md,
    marginBottom: spacing.md,
    minWidth: 80,
    alignItems: 'center',
  },
  timeChipText: {
    fontSize: typography.fontSize.base,
    color: colors.text,
  },
  summaryCard: {
    backgroundColor: colors.backgroundSecondary,
    padding: spacing.base,
    borderRadius: borderRadius.md,
    marginTop: spacing.xl,
  },
  summaryTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text,
    marginBottom: spacing.base,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: spacing.sm,
  },
  summaryLabel: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
  },
  summaryValue: {
    fontSize: typography.fontSize.base,
    fontWeight: typography.fontWeight.medium,
    color: colors.text,
  },
  footer: {
    padding: spacing.xl,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
});
