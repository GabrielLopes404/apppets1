import React from 'react';
import { ScrollView, RefreshControl, StyleSheet } from 'react-native';
import { colors } from '../../theme';

export const PullToRefresh = ({ 
  children, 
  onRefresh,
  refreshing = false,
  ...props 
}) => {
  return (
    <ScrollView
      contentContainerStyle={styles.container}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onRefresh}
          tintColor={colors.primary}
          colors={[colors.primary, colors.secondary]}
          progressBackgroundColor={colors.background}
        />
      }
      {...props}
    >
      {children}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
  },
});
