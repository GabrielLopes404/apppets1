import React from 'react';
import { View, StyleSheet, Platform } from 'react-native';
import { glassmorphism, shadows, borderRadius } from '../../theme';

export const GlassCard = ({ 
  children, 
  style, 
  variant = 'light',
  ...props 
}) => {
  return (
    <View 
      style={[
        styles.container,
        variant === 'light' && styles.light,
        variant === 'medium' && styles.medium,
        variant === 'dark' && styles.dark,
        style
      ]} 
      {...props}
    >
      {children}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    borderRadius: borderRadius.lg,
    ...shadows.md,
    ...Platform.select({
      web: {
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
      },
    }),
  },
  light: {
    ...glassmorphism.light,
  },
  medium: {
    ...glassmorphism.medium,
  },
  dark: {
    ...glassmorphism.dark,
  },
});
