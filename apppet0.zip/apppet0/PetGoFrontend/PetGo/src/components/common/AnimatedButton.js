import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator } from 'react-native';
import Animated, { 
  useSharedValue, 
  useAnimatedStyle, 
  withSpring, 
  withTiming 
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { colors, gradients, typography, spacing, borderRadius, shadows } from '../../theme';

const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);

export const AnimatedButton = ({ 
  title, 
  onPress, 
  variant = 'primary', 
  size = 'medium',
  gradient = null,
  icon,
  loading = false,
  disabled = false,
  style,
  ...props 
}) => {
  const scale = useSharedValue(1);
  const opacity = useSharedValue(1);
  
  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: opacity.value,
  }));
  
  const handlePressIn = () => {
    scale.value = withTiming(0.96, { duration: 100 });
  };
  
  const handlePressOut = () => {
    scale.value = withSpring(1, { damping: 12, stiffness: 300 });
  };
  
  const handlePress = () => {
    if (!disabled && !loading && onPress) {
      scale.value = withSpring(1.02, { damping: 15 }, () => {
        scale.value = withSpring(1);
      });
      onPress();
    }
  };
  
  const getButtonStyle = () => {
    const baseStyle = [styles.button, styles[size]];
    
    if (disabled || loading) {
      opacity.value = 0.6;
      return [...baseStyle, styles.disabled];
    }
    
    if (!gradient) {
      switch (variant) {
        case 'primary':
          return [...baseStyle, styles.primary];
        case 'secondary':
          return [...baseStyle, styles.secondary];
        case 'outline':
          return [...baseStyle, styles.outline];
        case 'ghost':
          return [...baseStyle, styles.ghost];
        default:
          return [...baseStyle, styles.primary];
      }
    }
    
    return baseStyle;
  };
  
  const getTextStyle = () => {
    const baseStyle = [styles.text, styles[`text${size.charAt(0).toUpperCase() + size.slice(1)}`]];
    
    switch (variant) {
      case 'outline':
      case 'ghost':
        return [...baseStyle, styles.textPrimary];
      default:
        return [...baseStyle, styles.textWhite];
    }
  };
  
  const renderContent = () => (
    <>
      {loading ? (
        <ActivityIndicator color={variant === 'outline' || variant === 'ghost' ? colors.primary : colors.textInverse} />
      ) : (
        <>
          {icon && <View style={styles.icon}>{icon}</View>}
          <Text style={getTextStyle()}>{title}</Text>
        </>
      )}
    </>
  );
  
  if (gradient && !disabled && !loading) {
    return (
      <AnimatedTouchable
        activeOpacity={0.9}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        onPress={handlePress}
        style={[animatedStyle, style]}
        {...props}
      >
        <LinearGradient
          colors={gradient}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={getButtonStyle()}
        >
          {renderContent()}
        </LinearGradient>
      </AnimatedTouchable>
    );
  }
  
  return (
    <AnimatedTouchable
      activeOpacity={0.9}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      onPress={handlePress}
      style={[getButtonStyle(), animatedStyle, style]}
      disabled={disabled || loading}
      {...props}
    >
      {renderContent()}
    </AnimatedTouchable>
  );
};

const styles = StyleSheet.create({
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: borderRadius.lg,
    ...shadows.md,
  },
  small: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.base,
    minHeight: 36,
  },
  medium: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xl,
    minHeight: 48,
  },
  large: {
    paddingVertical: spacing.base,
    paddingHorizontal: spacing['2xl'],
    minHeight: 56,
  },
  primary: {
    backgroundColor: colors.primary,
  },
  secondary: {
    backgroundColor: colors.secondary,
  },
  outline: {
    backgroundColor: 'transparent',
    borderWidth: 2,
    borderColor: colors.primary,
  },
  ghost: {
    backgroundColor: 'transparent',
  },
  disabled: {
    opacity: 0.6,
  },
  text: {
    fontWeight: typography.fontWeight.semibold,
    textAlign: 'center',
  },
  textSmall: {
    fontSize: typography.fontSize.sm,
  },
  textMedium: {
    fontSize: typography.fontSize.base,
  },
  textLarge: {
    fontSize: typography.fontSize.lg,
  },
  textWhite: {
    color: colors.textInverse,
  },
  textPrimary: {
    color: colors.primary,
  },
  icon: {
    marginRight: spacing.sm,
  },
});
