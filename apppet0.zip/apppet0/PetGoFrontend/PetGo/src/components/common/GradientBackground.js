import React from 'react';
import { StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { gradients } from '../../theme';

export const GradientBackground = ({ 
  children, 
  colors: customColors,
  preset = 'primary',
  start = { x: 0, y: 0 },
  end = { x: 1, y: 1 },
  style,
  ...props 
}) => {
  const getColors = () => {
    if (customColors) return customColors;
    
    switch (preset) {
      case 'primary':
        return gradients.primary;
      case 'secondary':
        return gradients.secondary;
      case 'accent':
        return gradients.accent;
      case 'sunset':
        return gradients.sunset;
      case 'ocean':
        return gradients.ocean;
      case 'forest':
        return gradients.forest;
      case 'pinkPurple':
        return gradients.pinkPurple;
      case 'blueGreen':
        return gradients.blueGreen;
      case 'orangeRed':
        return gradients.orangeRed;
      case 'purpleBlue':
        return gradients.purpleBlue;
      case 'warmFlame':
        return gradients.warmFlame;
      default:
        return gradients.primary;
    }
  };
  
  return (
    <LinearGradient
      colors={getColors()}
      start={start}
      end={end}
      style={[styles.gradient, style]}
      {...props}
    >
      {children}
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  gradient: {
    flex: 1,
  },
});
