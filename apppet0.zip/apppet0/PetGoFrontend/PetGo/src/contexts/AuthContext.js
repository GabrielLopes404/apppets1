import React, { createContext, useState, useContext } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { mockUser } from '../data/mockData';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const login = async (email, password) => {
    setIsLoading(true);
    setTimeout(async () => {
      setUser(mockUser);
      await AsyncStorage.setItem('user', JSON.stringify(mockUser));
      setIsLoading(false);
    }, 1000);
  };

  const register = async (userData) => {
    setIsLoading(true);
    setTimeout(async () => {
      const newUser = { ...mockUser, ...userData };
      setUser(newUser);
      await AsyncStorage.setItem('user', JSON.stringify(newUser));
      setIsLoading(false);
    }, 1000);
  };

  const logout = async () => {
    setUser(null);
    await AsyncStorage.removeItem('user');
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
