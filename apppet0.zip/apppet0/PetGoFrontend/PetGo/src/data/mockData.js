export const mockStores = [
  {
    id: '1',
    name: 'PetSpa Premium',
    category: 'Banho e Tosa',
    rating: 4.8,
    reviewCount: 234,
    distance: '1.2 km',
    image: 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=400',
    description: 'Banho e tosa especializada para pets de todos os portes',
    hours: 'Seg-Sáb: 8h-18h',
    phone: '(11) 98765-4321',
  },
  {
    id: '2',
    name: 'Clínica Veterinária Vida Animal',
    category: 'Veterinário',
    rating: 4.9,
    reviewCount: 567,
    distance: '800 m',
    image: 'https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=400',
    description: 'Clínica veterinária completa com atendimento 24h',
    hours: '24 horas',
    phone: '(11) 91234-5678',
  },
  {
    id: '3',
    name: 'PetShop Central',
    category: 'Produtos',
    rating: 4.7,
    reviewCount: 189,
    distance: '2.5 km',
    image: 'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=400',
    description: 'Variedade completa de produtos para seu pet',
    hours: 'Seg-Dom: 9h-21h',
    phone: '(11) 97777-8888',
  },
];

export const mockProducts = [
  {
    id: '1',
    storeId: '3',
    name: 'Ração Premium Adultos 15kg',
    price: 189.90,
    image: 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=400',
    description: 'Ração super premium para cães adultos, com alto teor de proteínas',
    category: 'Alimentos',
  },
  {
    id: '2',
    storeId: '3',
    name: 'Brinquedo Interativo',
    price: 45.90,
    image: 'https://images.unsplash.com/photo-1535294435445-d7249524ef2e?w=400',
    description: 'Brinquedo educativo e interativo para cães',
    category: 'Brinquedos',
  },
  {
    id: '3',
    storeId: '3',
    name: 'Cama Confort Plus',
    price: 129.90,
    image: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=400',
    description: 'Cama ultra confortável para pets de médio porte',
    category: 'Camas e Acessórios',
  },
];

export const mockServices = [
  {
    id: '1',
    storeId: '1',
    name: 'Banho Simples',
    price: 60.00,
    duration: '45 min',
    description: 'Banho completo com shampoo e condicionador',
  },
  {
    id: '2',
    storeId: '1',
    name: 'Banho e Tosa',
    price: 120.00,
    duration: '1h 30min',
    description: 'Banho completo + tosa higiênica ou completa',
  },
  {
    id: '3',
    storeId: '2',
    name: 'Consulta Veterinária',
    price: 180.00,
    duration: '30 min',
    description: 'Consulta geral com veterinário especializado',
  },
];

export const mockPets = [
  {
    id: '1',
    name: 'Rex',
    type: 'Cachorro',
    breed: 'Labrador',
    age: '3 anos',
    image: 'https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400',
  },
  {
    id: '2',
    name: 'Luna',
    type: 'Gato',
    breed: 'Siamês',
    age: '2 anos',
    image: 'https://images.unsplash.com/photo-1574158622682-e40e69881006?w=400',
  },
];

export const mockUser = {
  id: '1',
  name: 'João Silva',
  email: 'joao@example.com',
  phone: '(11) 98765-4321',
  addresses: [
    {
      id: '1',
      street: 'Rua das Flores, 123',
      neighborhood: 'Centro',
      city: 'São Paulo',
      state: 'SP',
      zipCode: '01234-567',
      isDefault: true,
    },
  ],
};

export const mockOrders = [
  {
    id: '1',
    date: '2024-11-05',
    status: 'Entregue',
    total: 189.90,
    items: [
      {
        productId: '1',
        name: 'Ração Premium Adultos 15kg',
        quantity: 1,
        price: 189.90,
      },
    ],
  },
  {
    id: '2',
    date: '2024-11-08',
    status: 'Em andamento',
    total: 175.80,
    items: [
      {
        productId: '2',
        name: 'Brinquedo Interativo',
        quantity: 1,
        price: 45.90,
      },
      {
        productId: '3',
        name: 'Cama Confort Plus',
        quantity: 1,
        price: 129.90,
      },
    ],
  },
];

export const mockReviews = [
  {
    id: '1',
    storeId: '1',
    userName: 'Maria Santos',
    rating: 5,
    comment: 'Excelente atendimento! Meu cachorro ficou limpinho e cheiroso.',
    date: '2024-11-01',
  },
  {
    id: '2',
    storeId: '1',
    userName: 'Pedro Lima',
    rating: 4,
    comment: 'Muito bom, mas demorou um pouco mais que o esperado.',
    date: '2024-10-28',
  },
];
