import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { StoreCard } from '../../components/ui/StoreCard';
import { CategoryChip } from '../../components/ui/CategoryChip';
import { Banner } from '../../components/ui/Banner';
import { SearchBar } from '../../components/common/SearchBar';
import { Tag } from '../../components/common/Tag';
import { Divider } from '../../components/common/Divider';
import { SkeletonLoader } from '../../components/common';
import { mockStores, mockBanners } from '../../data/mockData';
import { colors, typography, spacing, layout } from '../../theme';

export const HomeScreen = ({ navigation }) => {
  const [stores, setStores] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedFilter, setSelectedFilter] = useState(null);

  const categories = [
    { id: 'dogs', label: 'Cachorros', icon: <Ionicons name="paw" size={24} color={colors.categories.dogs} /> },
    { id: 'cats', label: 'Gatos', icon: <Ionicons name="paw" size={24} color={colors.categories.cats} /> },
    { id: 'grooming', label: 'Banho & Tosa', icon: <Ionicons name="cut" size={24} color={colors.categories.grooming} /> },
    { id: 'veterinary', label: 'Veterinário', icon: <Ionicons name="medical" size={24} color={colors.categories.veterinary} /> },
    { id: 'products', label: 'Produtos', icon: <Ionicons name="cart" size={24} color={colors.categories.products} /> },
    { id: 'nearby', label: 'Próximas', icon: <Ionicons name="location" size={24} color={colors.primary} /> },
  ];

  const filters = [
    { id: 'freeDelivery', label: 'Entrega Grátis' },
    { id: 'fastDelivery', label: 'Entrega Expressa' },
    { id: 'promotions', label: 'Promoções' },
    { id: 'schedule', label: 'Agendar Serviço' },
    { id: '24h', label: '24 Horas' },
    { id: 'popular', label: 'Popular' },
  ];

  useEffect(() => {
    setTimeout(() => {
      setStores(mockStores);
      setIsLoading(false);
    }, 1000);
  }, []);

  const filteredStores = stores.filter(store => {
    const matchesSearch = store.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory ||
      (selectedCategory === 'grooming' && store.category === 'Banho e Tosa') ||
      (selectedCategory === 'veterinary' && store.category === 'Veterinário') ||
      (selectedCategory === 'products' && store.category === 'Produtos');
    const matchesFilter = !selectedFilter || 
      (selectedFilter === 'freeDelivery' && store.freeDelivery) ||
      (selectedFilter === 'fastDelivery' && store.fastDelivery) ||
      (selectedFilter === '24h' && store.hours === '24 horas') ||
      (selectedFilter === 'popular' && store.rating >= 4.7);
    return matchesSearch && matchesCategory && matchesFilter;
  });

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.locationContainer}>
          <Ionicons name="location" size={20} color={colors.primary} />
          <View style={styles.locationInfo}>
            <Text style={styles.locationLabel}>Entregar em</Text>
            <Text style={styles.locationText}>Asa Sul, Brasília</Text>
          </View>
          <Ionicons name="chevron-down" size={16} color={colors.textSecondary} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.notificationButton}>
          <Ionicons name="notifications-outline" size={24} color={colors.text} />
          <View style={styles.notificationBadge}>
            <Text style={styles.badgeText}>3</Text>
          </View>
        </TouchableOpacity>
      </View>

      <View style={styles.searchSection}>
        <SearchBar
          placeholder="Buscar ração, acessórios, banho e tosa..."
          value={searchQuery}
          onChangeText={setSearchQuery}
          onFocus={() => {}}
        />
      </View>

      <ScrollView 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.bannersSection}>
          <FlatList
            data={mockBanners}
            horizontal
            showsHorizontalScrollIndicator={false}
            keyExtractor={item => item.id}
            renderItem={({ item }) => (
              <Banner
                banner={item}
                onPress={() => {}}
              />
            )}
            contentContainerStyle={styles.bannersList}
          />
        </View>

        <View style={styles.categoriesSection}>
          <FlatList
            data={categories}
            horizontal
            showsHorizontalScrollIndicator={false}
            keyExtractor={item => item.id}
            renderItem={({ item }) => (
              <CategoryChip
                icon={item.icon}
                label={item.label}
                selected={selectedCategory === item.id}
                onPress={() => setSelectedCategory(
                  selectedCategory === item.id ? null : item.id
                )}
              />
            )}
            contentContainerStyle={styles.categoriesList}
          />
        </View>

        <View style={styles.filtersSection}>
          <FlatList
            data={filters}
            horizontal
            showsHorizontalScrollIndicator={false}
            keyExtractor={item => item.id}
            renderItem={({ item }) => (
              <Tag
                selected={selectedFilter === item.id}
                onPress={() => setSelectedFilter(
                  selectedFilter === item.id ? null : item.id
                )}
                style={styles.filterTag}
              >
                {item.label}
              </Tag>
            )}
            contentContainerStyle={styles.filtersList}
          />
        </View>

        <Divider spacing="md" />

        <View style={styles.storesSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Lojas e Clínicas</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>Ver todas</Text>
            </TouchableOpacity>
          </View>

          {isLoading ? (
            <>
              <SkeletonLoader width="100%" height={240} style={styles.skeleton} />
              <SkeletonLoader width="100%" height={240} style={styles.skeleton} />
              <SkeletonLoader width="100%" height={240} style={styles.skeleton} />
            </>
          ) : filteredStores.length > 0 ? (
            filteredStores.map((store) => (
              <StoreCard
                key={store.id}
                store={store}
                onPress={() => navigation.navigate('Store', { store })}
              />
            ))
          ) : (
            <View style={styles.emptyState}>
              <Ionicons name="search-outline" size={64} color={colors.textTertiary} />
              <Text style={styles.emptyStateTitle}>Nenhuma loja encontrada</Text>
              <Text style={styles.emptyStateText}>
                Tente ajustar seus filtros de busca
              </Text>
            </View>
          )}
        </View>

        <View style={styles.bottomSpacing} />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: layout.screenPadding,
    paddingVertical: spacing.md,
    backgroundColor: colors.background,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  locationInfo: {
    marginLeft: spacing.sm,
    flex: 1,
  },
  locationLabel: {
    fontSize: typography.fontSize.xs,
    color: colors.textSecondary,
    fontWeight: typography.fontWeight.regular,
  },
  locationText: {
    fontSize: typography.fontSize.base,
    color: colors.text,
    fontWeight: typography.fontWeight.semibold,
  },
  notificationButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.backgroundSecondary,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  notificationBadge: {
    position: 'absolute',
    top: -2,
    right: -2,
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: colors.error,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: {
    fontSize: 10,
    fontWeight: typography.fontWeight.bold,
    color: colors.textInverse,
  },
  searchSection: {
    paddingHorizontal: layout.screenPadding,
    paddingBottom: spacing.base,
  },
  scrollContent: {
    paddingBottom: spacing['4xl'],
  },
  bannersSection: {
    marginBottom: layout.sectionSpacing,
  },
  bannersList: {
    paddingHorizontal: layout.screenPadding,
  },
  categoriesSection: {
    marginBottom: spacing.base,
  },
  categoriesList: {
    paddingHorizontal: layout.screenPadding,
  },
  filtersSection: {
    marginBottom: spacing.base,
  },
  filtersList: {
    paddingHorizontal: layout.screenPadding,
  },
  filterTag: {
    marginRight: spacing.sm,
  },
  storesSection: {
    paddingHorizontal: layout.screenPadding,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.base,
  },
  sectionTitle: {
    fontSize: typography.fontSize.xl,
    fontWeight: typography.fontWeight.bold,
    color: colors.text,
  },
  seeAllText: {
    fontSize: typography.fontSize.sm,
    fontWeight: typography.fontWeight.semibold,
    color: colors.primary,
  },
  skeleton: {
    marginBottom: spacing.base,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: spacing['5xl'],
  },
  emptyStateTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text,
    marginTop: spacing.lg,
    marginBottom: spacing.sm,
  },
  emptyStateText: {
    fontSize: typography.fontSize.base,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  bottomSpacing: {
    height: spacing['3xl'],
  },
});
