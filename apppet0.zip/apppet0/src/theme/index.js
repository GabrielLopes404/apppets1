import { lightColors, darkColors, colors } from './colors';
import { typography } from './typography';
import { spacing, borderRadius, shadows } from './spacing';
import { layout } from './layout';

export const theme = {
  colors,
  lightColors,
  darkColors,
  typography,
  spacing,
  borderRadius,
  shadows,
  layout,
};

export { lightColors, darkColors, colors, typography, spacing, borderRadius, shadows, layout };
