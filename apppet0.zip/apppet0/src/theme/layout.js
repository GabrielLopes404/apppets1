import { Dimensions } from 'react-native';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export const layout = {
  screenPadding: 16,
  sectionSpacing: 24,
  containerMaxWidth: SCREEN_WIDTH > 768 ? 768 : SCREEN_WIDTH,
  headerHeight: 60,
  tabBarHeight: 60,
  
  isSmallScreen: SCREEN_WIDTH < 375,
  isMediumScreen: SCREEN_WIDTH >= 375 && SCREEN_WIDTH < 414,
  isLargeScreen: SCREEN_WIDTH >= 414,
};
