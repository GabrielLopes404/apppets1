export const lightColors = {
  primary: '#FF7A3D',
  primaryDark: '#E66A2D',
  primaryLight: '#FF8F5A',
  
  secondary: '#32C3FF',
  secondaryDark: '#22B3EF',
  secondaryLight: '#4DCDFF',
  
  accent: '#FFB84D',
  
  success: '#10B981',
  successLight: '#D1FAE5',
  warning: '#F59E0B',
  warningLight: '#FEF3C7',
  error: '#EF4444',
  errorLight: '#FEE2E2',
  info: '#3B82F6',
  infoLight: '#DBEAFE',
  
  background: '#FFFFFF',
  backgroundSecondary: '#F9FAFB',
  backgroundTertiary: '#F3F4F6',
  
  text: '#111827',
  textSecondary: '#6B7280',
  textTertiary: '#9CA3AF',
  textInverse: '#FFFFFF',
  
  border: '#E5E7EB',
  borderLight: '#F3F4F6',
  
  card: '#FFFFFF',
  cardHover: '#FAFAFA',
  
  overlay: 'rgba(0, 0, 0, 0.5)',
  overlayLight: 'rgba(0, 0, 0, 0.25)',
  
  rating: '#FBBF24',
  
  badge: {
    express: '#EF4444',
    free: '#10B981',
    new: '#3B82F6',
    popular: '#F59E0B',
  },
  
  categories: {
    dogs: '#FF7A3D',
    cats: '#32C3FF',
    grooming: '#A855F7',
    veterinary: '#10B981',
    products: '#F59E0B',
  },
  
  status: {
    preparing: '#F59E0B',
    inTransit: '#3B82F6',
    delivered: '#10B981',
    cancelled: '#EF4444',
  },
};

export const darkColors = {
  ...lightColors,
  
  background: '#111827',
  backgroundSecondary: '#1F2937',
  backgroundTertiary: '#374151',
  
  text: '#F9FAFB',
  textSecondary: '#D1D5DB',
  textTertiary: '#9CA3AF',
  textInverse: '#111827',
  
  border: '#374151',
  borderLight: '#4B5563',
  
  card: '#1F2937',
  cardHover: '#374151',
  
  overlay: 'rgba(0, 0, 0, 0.75)',
};

export const colors = lightColors;
