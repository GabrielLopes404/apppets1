import { Dimensions, Platform } from 'react-native';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

export const isSmallDevice = SCREEN_WIDTH < 375;
export const isMediumDevice = SCREEN_WIDTH >= 375 && SCREEN_WIDTH < 414;
export const isLargeDevice = SCREEN_WIDTH >= 414;

export const getResponsiveSize = (base, options = {}) => {
  const { small = base * 0.9, medium = base, large = base * 1.1 } = options;
  
  if (isSmallDevice) return small;
  if (isMediumDevice) return medium;
  return large;
};

export const hp = (percentage) => {
  return (SCREEN_HEIGHT * percentage) / 100;
};

export const wp = (percentage) => {
  return (SCREEN_WIDTH * percentage) / 100;
};

export const isWeb = Platform.OS === 'web';
export const isIOS = Platform.OS === 'ios';
export const isAndroid = Platform.OS === 'android';
