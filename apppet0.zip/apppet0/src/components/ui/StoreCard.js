import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
import Animated, { 
  useSharedValue, 
  useAnimatedStyle, 
  withSpring, 
  withTiming 
} from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';
import { Badge } from '../common/Badge';

const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);

export const StoreCard = ({ store, onPress }) => {
  const scale = useSharedValue(1);
  
  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));
  
  const handlePressIn = () => {
    scale.value = withTiming(0.98, { duration: 100 });
  };
  
  const handlePressOut = () => {
    scale.value = withSpring(1, { damping: 15 });
  };
  
  return (
    <AnimatedTouchable
      activeOpacity={0.95}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      onPress={onPress}
      style={[styles.container, animatedStyle, shadows.md]}
    >
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: store.image }}
          style={styles.image}
          resizeMode="cover"
        />
        
        {(store.fastDelivery || store.freeDelivery || store.isNew) && (
          <View style={styles.topBadges}>
            {store.isNew && (
              <View style={[styles.badgePill, styles.newBadge]}>
                <Text style={styles.badgeText}>NOVO</Text>
              </View>
            )}
            {store.fastDelivery && (
              <View style={[styles.badgePill, styles.expressBadge]}>
                <Ionicons name="flash" size={12} color={colors.textInverse} />
                <Text style={styles.badgeText}>RÁPIDO</Text>
              </View>
            )}
            {store.freeDelivery && (
              <View style={[styles.badgePill, styles.freeBadge]}>
                <Text style={styles.badgeText}>GRÁTIS</Text>
              </View>
            )}
          </View>
        )}
      </View>
      
      <View style={styles.content}>
        <View style={styles.mainInfo}>
          <Text style={styles.name} numberOfLines={1}>{store.name}</Text>
          <View style={styles.ratingContainer}>
            <View style={styles.ratingBadge}>
              <Ionicons name="star" size={12} color="#FFF" />
              <Text style={styles.ratingValue}>{store.rating.toFixed(1)}</Text>
            </View>
          </View>
        </View>
        
        <Text style={styles.category} numberOfLines={1}>{store.category}</Text>
        
        <View style={styles.separator} />
        
        <View style={styles.footer}>
          <View style={styles.infoGroup}>
            <View style={styles.infoItem}>
              <Ionicons name="time-outline" size={16} color={colors.textSecondary} />
              <Text style={styles.infoText}>{store.deliveryTime}</Text>
            </View>
            
            <View style={styles.infoDivider} />
            
            <View style={styles.infoItem}>
              <Ionicons name="location-outline" size={16} color={colors.textSecondary} />
              <Text style={styles.infoText}>{store.distance}</Text>
            </View>
          </View>
          
          <View style={styles.deliveryFee}>
            {store.deliveryFee > 0 ? (
              <Text style={styles.feeText}>R$ {store.deliveryFee.toFixed(2)}</Text>
            ) : (
              <View style={styles.freeDeliveryBadge}>
                <Text style={styles.freeDeliveryText}>GRÁTIS</Text>
              </View>
            )}
          </View>
        </View>
      </View>
    </AnimatedTouchable>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: spacing.lg,
    borderRadius: borderRadius.xl,
    overflow: 'hidden',
    backgroundColor: colors.card,
  },
  imageContainer: {
    position: 'relative',
  },
  image: {
    width: '100%',
    height: 200,
    backgroundColor: colors.backgroundSecondary,
  },
  topBadges: {
    position: 'absolute',
    top: spacing.md,
    left: spacing.md,
    flexDirection: 'row',
    gap: spacing.xs,
  },
  badgePill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: borderRadius.full,
    gap: 4,
  },
  newBadge: {
    backgroundColor: colors.primary,
  },
  expressBadge: {
    backgroundColor: colors.secondary,
  },
  freeBadge: {
    backgroundColor: colors.success,
  },
  badgeText: {
    fontSize: 10,
    fontWeight: typography.fontWeight.bold,
    color: colors.textInverse,
    letterSpacing: 0.5,
  },
  content: {
    padding: spacing.base,
  },
  mainInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.xs,
  },
  name: {
    flex: 1,
    fontSize: typography.fontSize.xl,
    fontWeight: typography.fontWeight.bold,
    color: colors.text,
    marginRight: spacing.sm,
  },
  ratingContainer: {
    flexShrink: 0,
  },
  ratingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.rating,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: borderRadius.sm,
    gap: 4,
  },
  ratingValue: {
    fontSize: typography.fontSize.sm,
    fontWeight: typography.fontWeight.bold,
    color: colors.textInverse,
  },
  category: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    fontWeight: typography.fontWeight.medium,
    marginBottom: spacing.sm,
  },
  separator: {
    height: 1,
    backgroundColor: colors.border,
    marginBottom: spacing.sm,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  infoGroup: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  infoDivider: {
    width: 1,
    height: 12,
    backgroundColor: colors.border,
    marginHorizontal: spacing.md,
  },
  infoText: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    fontWeight: typography.fontWeight.medium,
  },
  deliveryFee: {
    marginLeft: spacing.md,
  },
  feeText: {
    fontSize: typography.fontSize.sm,
    fontWeight: typography.fontWeight.semibold,
    color: colors.text,
  },
  freeDeliveryBadge: {
    backgroundColor: colors.successLight,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: borderRadius.sm,
  },
  freeDeliveryText: {
    fontSize: typography.fontSize.xs,
    fontWeight: typography.fontWeight.bold,
    color: colors.success,
    letterSpacing: 0.5,
  },
});
