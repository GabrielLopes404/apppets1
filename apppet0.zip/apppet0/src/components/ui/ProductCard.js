import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
import Animated, { 
  useSharedValue, 
  useAnimatedStyle, 
  withSpring, 
  withTiming 
} from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';

const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);

export const ProductCard = ({ product, onPress, onAddToCart, horizontal = false }) => {
  const scale = useSharedValue(1);
  
  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));
  
  const handlePressIn = () => {
    scale.value = withTiming(0.95, { duration: 100 });
  };
  
  const handlePressOut = () => {
    scale.value = withSpring(1, { damping: 12 });
  };
  
  if (horizontal) {
    return (
      <AnimatedTouchable
        activeOpacity={0.9}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        onPress={onPress}
        style={[styles.horizontalContainer, animatedStyle, shadows.sm]}
      >
        <Image
          source={{ uri: product.image }}
          style={styles.horizontalImage}
          resizeMode="cover"
        />
        <View style={styles.horizontalContent}>
          <View style={styles.horizontalInfo}>
            <Text style={styles.name} numberOfLines={2}>{product.name}</Text>
            {product.description && (
              <Text style={styles.description} numberOfLines={2}>
                {product.description}
              </Text>
            )}
          </View>
          <View style={styles.horizontalFooter}>
            <Text style={styles.price}>R$ {product.price.toFixed(2)}</Text>
            {onAddToCart && (
              <TouchableOpacity 
                style={styles.addButton}
                onPress={onAddToCart}
                activeOpacity={0.7}
              >
                <Ionicons name="add" size={20} color={colors.textInverse} />
              </TouchableOpacity>
            )}
          </View>
        </View>
      </AnimatedTouchable>
    );
  }
  
  return (
    <AnimatedTouchable
      activeOpacity={0.9}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      onPress={onPress}
      style={[styles.container, animatedStyle, shadows.base]}
    >
      <Image
        source={{ uri: product.image }}
        style={styles.image}
        resizeMode="cover"
      />
      <View style={styles.content}>
        <Text style={styles.name} numberOfLines={2}>{product.name}</Text>
        <View style={styles.footer}>
          <Text style={styles.price}>R$ {product.price.toFixed(2)}</Text>
          {onAddToCart && (
            <TouchableOpacity 
              style={styles.addButton}
              onPress={onAddToCart}
              activeOpacity={0.7}
            >
              <Ionicons name="add" size={18} color={colors.textInverse} />
            </TouchableOpacity>
          )}
        </View>
      </View>
    </AnimatedTouchable>
  );
};

const styles = StyleSheet.create({
  container: {
    width: 160,
    marginRight: spacing.md,
    borderRadius: borderRadius.md,
    backgroundColor: colors.card,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: 140,
    backgroundColor: colors.backgroundSecondary,
  },
  content: {
    padding: spacing.md,
  },
  name: {
    fontSize: typography.fontSize.sm,
    fontWeight: typography.fontWeight.medium,
    color: colors.text,
    marginBottom: spacing.sm,
    height: 34,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  price: {
    fontSize: typography.fontSize.md,
    fontWeight: typography.fontWeight.bold,
    color: colors.text,
  },
  addButton: {
    width: 32,
    height: 32,
    borderRadius: borderRadius.base,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  
  horizontalContainer: {
    flexDirection: 'row',
    marginBottom: spacing.md,
    borderRadius: borderRadius.md,
    backgroundColor: colors.card,
    overflow: 'hidden',
  },
  horizontalImage: {
    width: 100,
    height: 100,
    backgroundColor: colors.backgroundSecondary,
  },
  horizontalContent: {
    flex: 1,
    padding: spacing.md,
    justifyContent: 'space-between',
  },
  horizontalInfo: {
    flex: 1,
  },
  description: {
    fontSize: typography.fontSize.xs,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  horizontalFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});
