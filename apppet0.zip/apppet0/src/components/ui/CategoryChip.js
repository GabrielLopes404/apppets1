import React from 'react';
import { TouchableOpacity, Text, StyleSheet, View } from 'react-native';
import { colors, typography, spacing, borderRadius, shadows } from '../../theme';

export const CategoryChip = ({ 
  icon, 
  label, 
  selected = false, 
  onPress,
  style 
}) => {
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[
        styles.container,
        selected && styles.selected,
        selected && shadows.sm,
        style
      ]}
      activeOpacity={0.7}
    >
      <View style={[
        styles.iconContainer,
        selected && styles.iconContainerSelected
      ]}>
        {icon}
      </View>
      <Text style={[
        styles.label,
        selected && styles.labelSelected
      ]}>
        {label}
      </Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    marginRight: spacing.md,
  },
  iconContainer: {
    width: 56,
    height: 56,
    borderRadius: borderRadius.md,
    backgroundColor: colors.backgroundSecondary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  iconContainerSelected: {
    backgroundColor: colors.primary,
  },
  label: {
    fontSize: typography.fontSize.xs,
    fontWeight: typography.fontWeight.medium,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  labelSelected: {
    color: colors.text,
    fontWeight: typography.fontWeight.semibold,
  },
  selected: {
    backgroundColor: colors.backgroundSecondary,
    borderRadius: borderRadius.md,
  },
});
