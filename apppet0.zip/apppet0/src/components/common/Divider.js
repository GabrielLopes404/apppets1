import React from 'react';
import { View, StyleSheet } from 'react-native';
import { colors, spacing } from '../../theme';

export const Divider = ({ style, vertical = false, spacing: dividerSpacing }) => {
  if (vertical) {
    return (
      <View style={[
        styles.vertical,
        dividerSpacing && { marginHorizontal: spacing[dividerSpacing] },
        style
      ]} />
    );
  }
  
  return (
    <View style={[
      styles.horizontal,
      dividerSpacing && { marginVertical: spacing[dividerSpacing] },
      style
    ]} />
  );
};

const styles = StyleSheet.create({
  horizontal: {
    height: 1,
    backgroundColor: colors.border,
  },
  vertical: {
    width: 1,
    backgroundColor: colors.border,
  },
});
