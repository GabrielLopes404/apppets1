import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, typography, spacing, borderRadius } from '../../theme';

export const Badge = ({ 
  children, 
  variant = 'default',
  size = 'sm',
  style,
  textStyle,
}) => {
  const variantStyles = {
    express: { backgroundColor: colors.badge.express },
    free: { backgroundColor: colors.badge.free },
    new: { backgroundColor: colors.badge.new },
    popular: { backgroundColor: colors.badge.popular },
    default: { backgroundColor: colors.textSecondary },
  };

  const sizeStyles = {
    xs: {
      paddingHorizontal: spacing.xs,
      paddingVertical: 2,
      fontSize: typography.fontSize.xs,
    },
    sm: {
      paddingHorizontal: spacing.sm,
      paddingVertical: spacing.xs,
      fontSize: typography.fontSize.xs,
    },
    md: {
      paddingHorizontal: spacing.md,
      paddingVertical: spacing.sm,
      fontSize: typography.fontSize.sm,
    },
  };

  return (
    <View style={[
      styles.badge,
      variantStyles[variant],
      sizeStyles[size],
      style
    ]}>
      <Text style={[styles.text, textStyle]}>{children}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  badge: {
    borderRadius: borderRadius.sm,
    alignSelf: 'flex-start',
  },
  text: {
    color: colors.textInverse,
    fontWeight: typography.fontWeight.semibold,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
});
