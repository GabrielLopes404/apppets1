import React from 'react';
import { View, StyleSheet } from 'react-native';
import { colors, shadows, borderRadius } from '../../theme';

export const Surface = ({ 
  children, 
  elevation = 'base',
  rounded = 'md',
  padding,
  style,
  ...props 
}) => {
  return (
    <View 
      style={[
        styles.surface,
        shadows[elevation],
        {
          borderRadius: borderRadius[rounded],
          padding: padding,
        },
        style
      ]}
      {...props}
    >
      {children}
    </View>
  );
};

const styles = StyleSheet.create({
  surface: {
    backgroundColor: colors.card,
  },
});
