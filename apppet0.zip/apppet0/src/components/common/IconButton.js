import React from 'react';
import { TouchableOpacity, StyleSheet } from 'react-native';
import { colors, spacing, borderRadius } from '../../theme';

export const IconButton = ({ 
  icon, 
  onPress, 
  size = 'md',
  variant = 'default',
  style,
}) => {
  const sizes = {
    sm: 32,
    md: 40,
    lg: 48,
  };

  const variants = {
    default: {
      backgroundColor: colors.backgroundSecondary,
    },
    primary: {
      backgroundColor: colors.primary,
    },
    transparent: {
      backgroundColor: 'transparent',
    },
  };

  return (
    <TouchableOpacity
      onPress={onPress}
      style={[
        styles.button,
        {
          width: sizes[size],
          height: sizes[size],
        },
        variants[variant],
        style,
      ]}
      activeOpacity={0.7}
    >
      {icon}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    borderRadius: borderRadius.base,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
